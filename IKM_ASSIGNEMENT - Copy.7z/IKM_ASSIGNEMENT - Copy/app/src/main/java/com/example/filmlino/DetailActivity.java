package com.example.filmlino;

public class DetailActivity {
}
