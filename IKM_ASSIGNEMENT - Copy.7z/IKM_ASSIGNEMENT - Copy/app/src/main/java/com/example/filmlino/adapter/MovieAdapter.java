package com.example.filmlino.adapter;

import com.example.filmlino.MainActivity;
import com.example.filmlino.model.Movie;

import java.util.List;

public class MovieAdapter {
    public MovieAdapter(MainActivity mainActivity, List<Movie> movieList) {

    }

    public void notifyDataSetChanged() {

    }
}
